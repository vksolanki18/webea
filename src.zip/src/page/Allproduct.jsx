import React from 'react'
import imgess from '../imges/shoes-imges.jpeg'
export default function Allproduct() {
    return (
        <div >
        <h3 style={{marginLeft:"150px", padding:"10px", marginTop:"50px" }}>More from this seller</h3>
        <div style={ {marginLeft:"120px",marginRight:"120px", padding: "15px" ,marginTop:"20px",display:"flex" }} >

          
                    <div class="row gx-4 gx-lg-5 row-cols-2 row-cols-md-3 row-cols-xl-4 justify-content-center">
                        <div class="col mb-5">
                            <div class="card h-30">
                            <div class="badge bg-dark text-white position-absolute" style={{top: "0.5rem", right: "0.5rem"}}>Sale</div>
                                <img class="card-img-top"  src={imgess} width={"80px"}height={"120px"} alt="..." />
                                <div class="card-body p-1 ">
                                    <div class="text-center">
                                        <h6 class="fw-bolder">Round toe Leather loafer shoes(black)</h6>
                                        $40.00 - $80.00
                                    </div>
                                </div>
                                <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                    <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="#">View options</a></div>
                                </div>
                            </div>
                        </div>
                        <div class="col mb-5">
                            <div class="card h-30">
                            <div class="badge bg-dark text-white position-absolute" style={{top: "0.5rem", right: "0.5rem"}}>Sale</div>
                                <img class="card-img-top"  src={imgess} width={"80px"}height={"120px"} alt="..." />
                                <div class="card-body p-1 ">
                                    <div class="text-center">
                                    <h6 class="fw-bolder">Round toe Leather loafer shoes(black)</h6>

                                        $40.00 - $80.00
                                    </div>
                                </div>
                                <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                    <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="#">View options</a></div>
                                </div>
                            </div>
                        </div>
                        <div class="col mb-5">
                            <div class="card h-30">
                            <div class="badge bg-dark text-white position-absolute" style={{top: "0.5rem", right: "0.5rem"}}>Sale</div>
                                <img class="card-img-top"  src={imgess} width={"80px"}height={"120px"} alt="..." />
                                <div class="card-body p-1 ">
                                    <div class="text-center">
                                    <h6 class="fw-bolder">Round toe Leather loafer shoes(black)</h6>

                                        $40.00 - $80.00
                                    </div>
                                </div>
                                <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                    <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="#">View options</a></div>
                                </div>
                            </div>
                        </div>
                        <div class="col mb-5">
                            <div class="card h-30">
                            <div class="badge bg-dark text-white position-absolute" style={{top: "0.5rem", right: "0.5rem"}}>Sale</div>
                                <img class="card-img-top"  src={imgess} width={"80px"}height={"120px"} alt="..." />
                                <div class="card-body p-1 ">
                                    <div class="text-center">
                                    <h6 class="fw-bolder">Round toe Leather loafer shoes(black)</h6>

                                        $40.00 - $80.00
                                    </div>
                                </div>
                                <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                    <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="#">View options</a></div>
                                </div>
                            </div>
                        </div>
                        <div class="col mb-5">
                            <div class="card h-30">
                            <div class="badge bg-dark text-white position-absolute" style={{top: "0.5rem", right: "0.5rem"}}>Sale</div>
                                <img class="card-img-top"  src={imgess} width={"80px"}height={"120px"} alt="..." />
                                <div class="card-body p-1 ">
                                    <div class="text-center">
                                    <h6 class="fw-bolder">Round toe Leather loafer shoes(black)</h6>

                                        $40.00 - $80.00
                                    </div>
                                </div>
                                <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                    <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="#">View options</a></div>
                                </div>
                            </div>
                        </div>
                        <div class="col mb-5">
                            <div class="card h-30">
                            <div class="badge bg-dark text-white position-absolute" style={{top: "0.5rem", right: "0.5rem"}}>Sale</div>
                                <img class="card-img-top"  src={imgess} width={"80px"}height={"120px"} alt="..." />
                                <div class="card-body p-1 ">
                                    <div class="text-center">
                                    <h6 class="fw-bolder">Round toe Leather loafer shoes(black)</h6>

                                        $40.00 - $80.00
                                    </div>
                                </div>
                                <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                    <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="#">View options</a></div>
                                </div>
                            </div>
                        </div>
                       
                       
                       
                       
                         
                        
                        </div>
                        </div>  </div>
                        )
}
